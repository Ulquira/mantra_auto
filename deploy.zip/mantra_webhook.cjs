process.env.TZ = 'America/Lima';

const express = require('express');
const cron = require('node-cron');
const { processOrderById, runQueueCron } = require('./mantra_service.cjs');
const { runCron } = require('./mantra_cron.cjs');
const { syncAllTemplates } = require('./sync_all_template_reports.cjs');
require('dotenv').config();

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;

// Cron basado en Cola y Reprogramaciones (motor único de despacho, se ejecuta cada 30 segundos)
cron.schedule('*/30 * * * * *', async () => {
  await runQueueCron();
});
console.log(`⏰ Cron [Cola Eventos + Reprogramaciones] activado. Escaneando la cola cada 30 segundos...`);

// Cron Periódico de Sincronización de Reportes de Mantra (Cada 2 horas entre 8:00 AM y 6:00 PM hora Perú)
cron.schedule('0 8-18/2 * * *', async () => {
  console.log(`⏰ [Reporte Mantra] Iniciando sincronización periódica de reportes de plantillas de Mantra...`);
  try {
    const hoy = new Date().toISOString().slice(0, 10);
    // Sincronizar el día anterior y el día de hoy para consolidar métricas finales
    const d = new Date();
    d.setDate(d.getDate() - 1);
    const ayer = d.toISOString().slice(0, 10);
    await syncAllTemplates(ayer, hoy);
    console.log(`✅ [Reporte Mantra] Sincronización periódica de reportes completada.`);
  } catch (err) {
    console.error(`❌ Error en cron periódico de reportes:`, err.message);
  }
}, {
  timezone: 'America/Lima'
});
console.log(`⏰ Cron [Reporte Mantra] programado cada 2 horas entre 08:00 y 18:00 (America/Lima).`);

// Endpoint Webhook para recibir notificaciones por evento/cambio de estado
app.post('/webhook/estado-cambiado', async (req, res) => {
  const { ordenId, estado } = req.body;

  if (!ordenId) {
    return res.status(400).json({
      error: 'Parámetro "ordenId" es requerido.'
    });
  }

  // Si se envía el estado y no es 'Agendada', 'Pendiente' ni 'En camino', omitir
  if (estado && estado !== 'Agendada' && estado !== 'Pendiente' && estado !== 'En camino') {
    return res.status(200).json({
      message: `La orden ${ordenId} cambió al estado '${estado}'. No requiere notificación por WhatsApp.`
    });
  }

  console.log(`\n[WEBHOOK] Evento recibido para la orden ${ordenId} (Estado: ${estado || 'Agendada/Pendiente/En camino'})`);

  try {
    const result = await processOrderById(ordenId);

    if (result.success) {
      return res.status(200).json({
        ok: true,
        message: `Notificación enviada exitosamente para la orden ${ordenId}.`,
        data: result
      });
    } else {
      return res.status(400).json({
        ok: false,
        message: result.message || `No se pudo enviar la notificación para la orden ${ordenId}.`,
        details: result.errorDetail
      });
    }
  } catch (err) {
    console.error(`[ERROR WEBHOOK] Error procesando la orden ${ordenId}:`, err.message);
    return res.status(500).json({
      error: 'Error interno del servidor.',
      details: err.message
    });
  }
});

// Root route para probes de inicio de Azure App Service
app.get('/', (req, res) => {
  res.status(200).send('API Mantra WhatsApp Webhook is Running');
});

// Healthcheck
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'UP', timestamp: new Date().toISOString() });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Servidor Webhook corriendo en el puerto ${PORT}`);
  console.log(`📌 Endpoint para cambio de estado: POST /webhook/estado-cambiado`);
});
